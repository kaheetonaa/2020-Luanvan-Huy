# thesis-template
Mẫu luận văn tốt nghiệp trường Đại học Cần Thơ soạn thảo bằng LaTeX

Các bạn lưu ý, khi clone về, bạn nên đọc kỹ nội dung file chính thesis.tex để hiểu các lệnh cấu hình trong đó và chỉnh sửa lại theo ý của bạn. Mình soạn thảo trên Eclipse, sử dụng plugin TeXlipse, bạn nên sử dụng công cụ tương tự để tránh xảy ra lỗi. Nếu bạn sử dụng công cụ khác, bạn tự tìm cách cấu hình project cho phù hợp.

Cấu trúc thư mục:
<ul>
<li>images: chứa hình ảnh</li>
<li>chapters: chứa các files nội dung các chương</li>
</ul>
